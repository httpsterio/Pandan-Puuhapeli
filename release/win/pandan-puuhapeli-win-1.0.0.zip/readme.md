## Pandan Puuhapeli

![](https://github.com/httpsterio/Pandan-Puuhapeli/blob/main/panda.png)

Flash (AS2) -pohjainen lapsille suunnattu opetuspeli.

Peli toimii [Newgroundsin flash-emulaattorilla](https://www.newgrounds.com/flash/player)

## Tekijät

- Sami Mäkelä
- Jussi Surma-Aho
- Elli Vähäkangas
- Tiia Leppänen
- Sampsa Heiskanen